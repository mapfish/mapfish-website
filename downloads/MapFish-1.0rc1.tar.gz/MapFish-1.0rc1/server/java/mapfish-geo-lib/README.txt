To build the jar file you need to:

(1) download maven from http://maven.apache.org/download.html and unzip it somewhere
(2) changedir into /path/to/MapFish/server/java/mapfish-geo-lib
(3) launch the command /path/to/apache-maven-2.0.8/bin/mvn package

This should create the jar file mapfish-geo-lib-0.1.jar.
