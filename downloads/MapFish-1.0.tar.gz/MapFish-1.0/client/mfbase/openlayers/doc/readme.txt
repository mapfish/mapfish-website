Automatically generated OpenLayers API documentation is online:

  http://dev.openlayers.org/apidocs
