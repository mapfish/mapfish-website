from mapfishsample.tests import *

class TestEpflController(TestController):
    pass
