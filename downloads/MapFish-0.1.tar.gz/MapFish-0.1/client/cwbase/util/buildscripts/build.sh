#!/bin/sh

java -jar lib/custom_rhino.jar build.js "$@"
