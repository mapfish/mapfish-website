({
	title: "Link URL",
	url: "URL:",
	text: "Text:",
	set: "Set",
	urlInvalidMessage: "Invalid URL.  Enter a full URL like 'http://www.dojotoolkit.org'"	
})
