({
		invalidMessage: "* Der eingegebene Wert ist ungültig.",
		missingMessage: "* Der Wert wird benötigt.",
		rangeMessage: "* Der Wert liegt außerhalb des gültigen Bereichs."
})
