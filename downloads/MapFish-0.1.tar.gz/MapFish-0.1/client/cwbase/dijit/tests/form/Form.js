dojo.provide("dijit.tests.form.Form");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests.form.Form", dojo.moduleUrl("dijit", "tests/form/Form.html"));
}
