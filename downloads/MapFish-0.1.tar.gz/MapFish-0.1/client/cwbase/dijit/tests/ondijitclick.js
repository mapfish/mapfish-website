dojo.provide("dijit.tests.ondijitclick");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests.ondijitclick", dojo.moduleUrl("dijit", "tests/ondijitclick.html"));
}
