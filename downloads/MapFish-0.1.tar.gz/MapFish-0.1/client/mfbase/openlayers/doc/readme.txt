Automatically generated OpenLayers API documentation is online:

  http://dev.openlayers.org/docs/overview-tree.html
