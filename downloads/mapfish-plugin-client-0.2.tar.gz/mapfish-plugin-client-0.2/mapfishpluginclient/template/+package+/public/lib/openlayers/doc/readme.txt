Automatically generated OpenLayers API documentation is online:

  http://dev.openlayers.org/apidocs

More information on documentation is available from:

  http://trac.openlayers.org/wiki/Documentation
