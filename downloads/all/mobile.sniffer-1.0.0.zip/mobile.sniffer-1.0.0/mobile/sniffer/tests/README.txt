This module contains integration level unit tests for mobile.sniffer.

Invidual sniffing backends have their own test suites.