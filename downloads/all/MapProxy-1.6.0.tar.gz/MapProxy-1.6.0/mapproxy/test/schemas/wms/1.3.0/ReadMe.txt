This set of XML Schema Documents for OpenGIS� Web Map Service Version 
1.3.0 has been edited to reflect the corrigendum to document OGC 04-024
that are based on the change requests: 
OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
OGC 05-081r2 "Change to use relative paths"

Arliss Whiteside, 2005-11-22

