
from distutils.core import setup

setup(packages=['snip_infrastructure'],
      requires=['cffi'])
