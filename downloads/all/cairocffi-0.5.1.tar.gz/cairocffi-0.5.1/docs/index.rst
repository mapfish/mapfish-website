.. include:: ../README.rst


Documentation
-------------

.. toctree::

    overview
    api
    pixbuf
    cffi_api
    changelog
