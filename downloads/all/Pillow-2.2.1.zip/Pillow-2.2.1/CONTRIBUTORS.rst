Contributors (Pillow)
=====================

.. Note:: Contributors: please add your name here

- Alex Po <alex-86p __at__ yandex.ru>
- Anton Vlasenko <antares.spica __at__ gmail.com>
- Brian J. Crowell <brian __at__ fluggo.com>
- Bryant Mairs <bwmairs __at__ ucsc.edu>
- Christoph Gohlke <cgohlke __at__ uci.edu>
- Corey Richardson <corey __at__ octayn.net>
- Daniel Hahler <github __at__ thequod.de>
- David Schmidt <david.schmiddi.86 __at__ gmail.com>
- Eliot <saltycrane __at__ gmail.com>
- etienne <etienne.desautels __at__ gmail.com>
- Jannis Leidel <jannis __at__ leidel.info>
- Kyle MacFarlane <kyle __at__ deletethetrees.com>
- Lars Yencken <lars __at__ yencken.org>
- Liu Qishuai <lqs __at__ lqs.me>
- Manuel Ebert <Maebert __at__ UOS.de>
- Marc Abramowitz <marc __at__ marc-abramowitz.com>
- Matti Picus <gitmatti __at__ picus.org.il>
- Mikhail Korobov <kmike84 __at__ gmail.com>
- OCHIAI, Gouji <gjo.ext __at__ gmail.com>
- Oliver Tonnhofer <olt __at__ bogosoft.com>
- Phil Elson <pelson.pub __at__ gmail.com>
- Sandro Mani <manisandro __at__ gmail.com>
- Simon Law <simon.law __at__ ecometrica.com>
- Stéphane Klein <stephane __at__ harobed.org>
- Takeshi KOMIYA <i.tkomiya __at__ gmail.com>
- Tom Gross <tom __at__ toms-projekte.de>
- Tom Payne <twpayne __at__ gmail.com>
- Tyler Garner <garnertb __at__ gmail.com>
- tdesvenain <thomas.desvenain __at__ gmail.com>
- wiredfool <eric-github __at__ soroos.net>
