Datasets
========

The world factbook data come from a simplified version of the 
CIA Factbook + World Borders available at :
http://data.freemap.in/view/DataSet/1