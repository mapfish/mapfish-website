
/*
 * @include mapfishappminimal_layout.js
 */

Ext.namespace("mapfishappminimal");

(function() {
    // run mapfishappminimal.layout.init() when the page
    // is ready
    Ext.onReady(function() {
        mapfishappminimal.layout.init()
    });
})();
