

class Connector(object):
    pass
    
    