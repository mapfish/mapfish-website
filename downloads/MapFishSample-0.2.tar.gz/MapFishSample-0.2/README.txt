This file is for you to describe the MapFishSample application. Typically
you would include information such as the information below:

Installation and Setup
======================

Install ``MapFishSample`` using easy_install::

    easy_install MapFishSample

Make a config file as follows::

    paster make-config MapFishSample config.ini

Tweak the config file as appropriate and then setup the application::

    paster setup-app config.ini

Then you are ready to go.
