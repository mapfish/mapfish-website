Decorator module
---------------------------

Dependencies:

The decorator module requires Python 2.4.

Installation:

Unzip the archive in a directory called "decorator" in your Python path. 
For instance, on Unices you could give something like that:

$ unzip decorator.zip -d decorator

Testing:

Just go in the package directory and give

$ python doctester.py documentation.txt

This will generate the main.py file containing all the examples
discussed in the documentation, and will run the corresponding tests.
