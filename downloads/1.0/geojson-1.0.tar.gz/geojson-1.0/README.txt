geojson: encode/decode geodata
==============================

This package contains:

* The reference implementation of the Python geo interface:

  http://trac.gispython.org/lab/wiki/PythonGeoInterface

* Functions for encoding and decoding GeoJSON (http://geojson.org) formatted
  data.
