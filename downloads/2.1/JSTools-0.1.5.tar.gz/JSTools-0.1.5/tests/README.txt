======================
 Things to get tested
======================

Ordering
========

* requires... always before

* includes : anywhere


Multiple Library Build Tests
============================

* 2 file trees

* test against name collisions


Coverage
========

could be improved::

* jstools.jsmin 

* jstools.deps

* jstools.utils
