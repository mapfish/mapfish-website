"""WebHelpers is wide variety of functions for web applications and other
applications.
"""
