:mod:`webhelpers.html.tools`
================================================

.. automodule:: webhelpers.html.tools

.. currentmodule:: webhelpers.html.tools

.. autofunction:: auto_link

.. autofunction:: button_to

.. autofunction:: js_obfuscate

.. autofunction:: highlight

.. autofunction:: mail_to

.. autofunction:: strip_links

.. autofunction:: strip_tags
