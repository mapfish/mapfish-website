:mod:`webhelpers.html.converters`
================================================

.. automodule:: webhelpers.html.converters

.. currentmodule:: webhelpers.html.converters

.. autofunction:: format_paragraphs

.. autofunction:: markdown

.. autofunction:: nl2br

.. autofunction:: render

.. autofunction:: sanitize

.. autofunction:: textilize
